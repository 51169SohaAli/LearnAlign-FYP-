<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Instructor Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar close">
    <div class="logo-details">
      <img src="logo.png"alt="logo">
      <span class="logo_name">LearnAlign</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="InstructorDashboard.html">
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">Dashboard</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="InstructorDashboard.html">Dashboard</a></li>
        </ul>
      </li>
      <li>
       <li>
        <a href="outcomes.html">
          <i class='bx bx-bullseye' ></i>
          <span class="link_name">Outcomes</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="outcomes.html">Outcomes</a></li>
        </ul>
      </li>
      <li>
       <li>
        <a href="courses.html">
          <i class='bx bx-book-alt' ></i>
          <span class="link_name">Courses</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="courses.html">Courses</a></li>
        </ul>
      </li>
      <li>
        <a href="assessment.html">
          <i class='bx bx-list-check'></i>
          <span class="link_name">Assessments</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="assessment.html">Assessments</a></li>
        </ul>
      </li>
      <li>
        <a href="progressreport.php">
          <i class='bx bx-line-chart' ></i>
          <span class="link_name">Progress Report</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="progressreport.php">Progress Report</a></li>
        </ul>
      </li>
      <li>
          <a href="feedback.html">
            <i class='bx bx-comment' ></i>
            <span class="link_name">Feedback</span>
          </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="feedback.html">Feedback</a></li>
        </ul>
      </li>
  </li>
</ul>
  </div>
  <section class="home-section" style="background-color: #fff;">
    <div class="home-content">
      <i class='bx bx-menu' ></i>
      <div class="header-menu">
                    
                    
                    
                   
     <div class="user-container">
  <div class="user" onclick="toggleDropdown()">
    <div class="bg-img" id="userIcon"></div>
  </div>

  <div class="dropdown" id="userDropdown">
    <label for="profileInput">
      <div class="profile-pic" id="dropdownProfile" style="background-image: url('OIP.jpg')" title="Click to change profile picture"></div>
    </label>
    <input type="file" id="profileInput" accept="image/*" style="display: none" onchange="changeProfilePic(event)">
    
    <div class="divider"></div>

    <div class="logout-option" onclick="logout()">
      <i data-lucide="log-out"></i>
      <span>Log Out</span>
    </div>
  </div>
</div>


                </div>
            </div>
    </div>

    <main>
            
            <div class="page-header">
                <h1>Dashboard</h1>
                <small>Home / Dashboard</small>
            </div>
            
            <div class="page-content">

                 <div class="analytics">

                     <div class="course-card-grid" id="courseCardGrid"></div> 

                </div>
        
        

    </div>    
            
        </main>
  </section>
  <script>
  let arrow = document.querySelectorAll(".arrow");
  for (var i = 0; i < arrow.length; i++) {
    arrow[i].addEventListener("click", (e)=>{
   let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
   arrowParent.classList.toggle("showMenu");
    });
  }
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".bx-menu");
  console.log(sidebarBtn);
  sidebarBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("close");
  });
  </script>

   <script>
document.addEventListener("DOMContentLoaded", function() {
    fetch('fetchcourses.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            // TABLE (if you're using it elsewhere)
            const tableBody = document.querySelector("#cloTable tbody");
            if (tableBody) {
                tableBody.innerHTML = "";

                if (data.error || data.length === 0) {
                    const row = document.createElement("tr");
                    row.innerHTML = `<td colspan="3">${data.error || "No courses assigned."}</td>`;
                    tableBody.appendChild(row);
                } else {
                    data.forEach(course => {
                        const row = document.createElement("tr");
                        row.innerHTML = `
                            <td>${course.course_id}</td>
                            <td>${course.course_name}</td>
                            <td>${course.clo || 'No CLOs Mapped'}</td>
                        `;
                        tableBody.appendChild(row);
                    });
                }
            }

            // COURSE CARDS
            const container = document.getElementById("courseCardGrid");
            if (container) {
                container.innerHTML = "";

                if (data.error || data.length === 0) {
                    container.innerHTML = `<p>No courses assigned.</p>`;
                    return;
                }

                data.forEach(course => {
                    const card = document.createElement("div");
                    card.classList.add("course-card");
                    card.onclick = () => {
                        window.location.href = `courseDetails.php?course_id=${course.course_id}`;
                    };
                    card.innerHTML = `
                        <h3>${course.course_name}</h3>
                        <p><strong>Course Code:</strong> ${course.course_id}</p>
                        
                    `;
                    container.appendChild(card);
                });
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
});


function toggleDropdown() {
  const dropdown = document.getElementById("userDropdown");
  dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";

  fetch('get_instructors_name.php')
    .then(response => response.json())
    .then(data => {
      if (data.name) {
        document.getElementById("instructorName").textContent = data.name;
      } else {
        document.getElementById("instructorName").textContent = "Unknown Instructor";
      }
    });

  lucide.createIcons();
}

function logout() {
  alert("Logged out!");
  window.location.href = "login.html";
}

function changeProfilePic(event) {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function (e) {
      const imgData = e.target.result;

      // Set the image in both UI locations
      document.getElementById("userIcon").style.backgroundImage = `url('${imgData}')`;
      document.getElementById("dropdownProfile").style.backgroundImage = `url('${imgData}')`;

      // Save the image to localStorage
      localStorage.setItem("userProfilePic", imgData);
    };
    reader.readAsDataURL(file);
  }
}

document.addEventListener("click", function (event) {
  const user = document.querySelector(".user");
  const dropdown = document.getElementById("userDropdown");
  if (!user.contains(event.target) && !dropdown.contains(event.target)) {
    dropdown.style.display = "none";
  }
});

window.addEventListener("DOMContentLoaded", function () {
  const savedPic = localStorage.getItem("userProfilePic");
  if (savedPic) {
    document.getElementById("userIcon").style.backgroundImage = `url('${savedPic}')`;
    document.getElementById("dropdownProfile").style.backgroundImage = `url('${savedPic}')`;
  }
});



</script>
